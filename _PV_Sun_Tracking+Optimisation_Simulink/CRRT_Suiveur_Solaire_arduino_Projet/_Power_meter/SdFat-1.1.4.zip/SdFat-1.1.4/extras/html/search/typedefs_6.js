var searchData=
[
  ['off_5ftype',['off_type',['../classios__base.html#a45de7cca0d01da781f4b886179c65c22',1,'ios_base']]],
  ['openmode',['openmode',['../classios__base.html#aaa192ec0dccc43050715553a34644523',1,'ios_base']]]
];
