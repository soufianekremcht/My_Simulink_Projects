var searchData=
[
  ['volumelabel',['volumeLabel',['../structfat__boot.html#a9ee733f1b1abc0210ec8f9676bba2218',1,'fat_boot::volumeLabel()'],['../structfat32__boot.html#a8e6349f46344145a7320637a58107b3b',1,'fat32_boot::volumeLabel()']]],
  ['volumeserialnumber',['volumeSerialNumber',['../structfat__boot.html#ac05e88a0d27f0340ba008834361d2b20',1,'fat_boot::volumeSerialNumber()'],['../structfat32__boot.html#a20768678da224faefd8acf12cabdbfb8',1,'fat32_boot::volumeSerialNumber()']]]
];
